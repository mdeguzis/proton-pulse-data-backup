-- Schema export 2026-08-09
-- Table: user_configs (columns from API response headers)
-- Content-Range: */*

-- Table: author_avatars (columns from API response headers)
-- Content-Range: */*

-- Table: user_proton_configs (columns from API response headers)
-- Content-Range: */*

-- Table: user_systems (columns from API response headers)
-- Content-Range: */*

-- Table: admins (columns from API response headers)
-- Content-Range: */*

-- Table: banned_users (columns from API response headers)
-- Content-Range: */*

